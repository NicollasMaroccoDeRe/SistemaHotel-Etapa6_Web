CREATE DATABASE IF NOT EXISTS sistemahotel;
USE sistemahotel;

CREATE TABLE IF NOT EXISTS hospede (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100),
  cpf VARCHAR(20),
  telefone VARCHAR(20),
  email VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS reserva (
  id INT AUTO_INCREMENT PRIMARY KEY,
  hospede_id INT,
  data_checkin DATE,
  data_checkout DATE,
  valor_total DECIMAL(10,2),
  FOREIGN KEY (hospede_id) REFERENCES hospede(id)
);
