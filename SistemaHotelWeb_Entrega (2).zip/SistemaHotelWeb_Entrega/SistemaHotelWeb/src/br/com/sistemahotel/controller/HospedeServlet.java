package br.com.sistemahotel.controller;

import br.com.sistemahotel.dao.HospedeDAO;
import br.com.sistemahotel.model.Hospede;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet(urlPatterns = {"/hospedes"})
public class HospedeServlet extends HttpServlet {
    private final HospedeDAO dao = new HospedeDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            List<Hospede> list = dao.findAll();
            req.setAttribute("hospedes", list);
            req.getRequestDispatcher("/listarHospedes.jsp").forward(req, resp);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String nome = req.getParameter("nome");
        String cpf = req.getParameter("cpf");
        String telefone = req.getParameter("telefone");
        String email = req.getParameter("email");
        Hospede h = new Hospede(nome, cpf, telefone, email);
        try {
            dao.save(h);
            resp.sendRedirect(req.getContextPath() + "/hospedes");
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
