package br.com.sistemahotel.controller;

import br.com.sistemahotel.dao.ReservaDAO;
import br.com.sistemahotel.model.Reserva;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

@WebServlet(urlPatterns = {"/reservas"})
public class ReservaServlet extends HttpServlet {
    private final ReservaDAO dao = new ReservaDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            List<Reserva> list = dao.findAll();
            req.setAttribute("reservas", list);
            req.getRequestDispatcher("/listarReservas.jsp").forward(req, resp);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int hospedeId = Integer.parseInt(req.getParameter("hospedeId"));
        LocalDate checkin = LocalDate.parse(req.getParameter("checkin"));
        LocalDate checkout = LocalDate.parse(req.getParameter("checkout"));
        double valor = Double.parseDouble(req.getParameter("valor"));
        Reserva r = new Reserva(hospedeId, checkin, checkout, valor);
        try {
            dao.save(r);
            resp.sendRedirect(req.getContextPath() + "/reservas");
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
