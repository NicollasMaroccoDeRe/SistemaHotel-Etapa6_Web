package br.com.sistemahotel.dao;

import br.com.sistemahotel.model.Hospede;
import br.com.sistemahotel.util.ConnectionFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HospedeDAO {

    public void save(Hospede h) throws SQLException {
        String sql = "INSERT INTO hospede (nome, cpf, telefone, email) VALUES (?,?,?,?)";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, h.getNome());
            ps.setString(2, h.getCpf());
            ps.setString(3, h.getTelefone());
            ps.setString(4, h.getEmail());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) h.setId(rs.getInt(1));
            }
        }
    }

    public List<Hospede> findAll() throws SQLException {
        String sql = "SELECT id, nome, cpf, telefone, email FROM hospede";
        List<Hospede> list = new ArrayList<>();
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Hospede h = new Hospede();
                h.setId(rs.getInt("id"));
                h.setNome(rs.getString("nome"));
                h.setCpf(rs.getString("cpf"));
                h.setTelefone(rs.getString("telefone"));
                h.setEmail(rs.getString("email"));
                list.add(h);
            }
        }
        return list;
    }

    public Hospede findById(int id) throws SQLException {
        String sql = "SELECT id, nome, cpf, telefone, email FROM hospede WHERE id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Hospede h = new Hospede();
                    h.setId(rs.getInt("id"));
                    h.setNome(rs.getString("nome"));
                    h.setCpf(rs.getString("cpf"));
                    h.setTelefone(rs.getString("telefone"));
                    h.setEmail(rs.getString("email"));
                    return h;
                }
            }
        }
        return null;
    }
}
