package br.com.sistemahotel.dao;

import br.com.sistemahotel.model.Reserva;
import br.com.sistemahotel.util.ConnectionFactory;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ReservaDAO {

    public void save(Reserva r) throws SQLException {
        String sql = "INSERT INTO reserva (hospede_id, data_checkin, data_checkout, valor_total) VALUES (?,?,?,?)";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, r.getHospedeId());
            ps.setDate(2, Date.valueOf(r.getDataCheckin()));
            ps.setDate(3, Date.valueOf(r.getDataCheckout()));
            ps.setDouble(4, r.getValorTotal());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) r.setId(rs.getInt(1));
            }
        }
    }

    public List<Reserva> findAll() throws SQLException {
        String sql = "SELECT id, hospede_id, data_checkin, data_checkout, valor_total FROM reserva";
        List<Reserva> list = new ArrayList<>();
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Reserva r = new Reserva();
                r.setId(rs.getInt("id"));
                r.setHospedeId(rs.getInt("hospede_id"));
                r.setDataCheckin(rs.getDate("data_checkin").toLocalDate());
                r.setDataCheckout(rs.getDate("data_checkout").toLocalDate());
                r.setValorTotal(rs.getDouble("valor_total"));
                list.add(r);
            }
        }
        return list;
    }
}
