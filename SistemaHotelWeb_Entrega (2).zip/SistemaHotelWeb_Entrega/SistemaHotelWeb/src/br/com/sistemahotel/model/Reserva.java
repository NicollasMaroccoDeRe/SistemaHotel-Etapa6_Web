package br.com.sistemahotel.model;

import java.time.LocalDate;

public class Reserva {
    private int id;
    private int hospedeId;
    private LocalDate dataCheckin;
    private LocalDate dataCheckout;
    private double valorTotal;

    public Reserva() {}

    public Reserva(int id, int hospedeId, LocalDate dataCheckin, LocalDate dataCheckout, double valorTotal) {
        this.id = id; this.hospedeId = hospedeId; this.dataCheckin = dataCheckin; this.dataCheckout = dataCheckout; this.valorTotal = valorTotal;
    }

    public Reserva(int hospedeId, LocalDate dataCheckin, LocalDate dataCheckout, double valorTotal) {
        this.hospedeId = hospedeId; this.dataCheckin = dataCheckin; this.dataCheckout = dataCheckout; this.valorTotal = valorTotal;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getHospedeId() { return hospedeId; }
    public void setHospedeId(int hospedeId) { this.hospedeId = hospedeId; }
    public LocalDate getDataCheckin() { return dataCheckin; }
    public void setDataCheckin(LocalDate dataCheckin) { this.dataCheckin = dataCheckin; }
    public LocalDate getDataCheckout() { return dataCheckout; }
    public void setDataCheckout(LocalDate dataCheckout) { this.dataCheckout = dataCheckout; }
    public double getValorTotal() { return valorTotal; }
    public void setValorTotal(double valorTotal) { this.valorTotal = valorTotal; }
}
